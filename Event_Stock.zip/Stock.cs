﻿using System;
using System.Collections.Generic;
using System.Text;
using static EventDemo.Utility;

namespace EventDemo
{
    class Stock
    {
        string symbol;
        decimal price;

        public Stock(string symbol) { this.symbol = symbol; }

        public event EventHandler<PriceChangedEventArgs> PriceChanged;

        protected virtual void OnPriceChanged(PriceChangedEventArgs e)
        {
            PriceChanged?.Invoke(this, e);
        }

        public void PriceFluctuation()
        {
            //if (GetRandomInteger(2)==1)
            //Price = Price + GetRandomInteger(-10, 10);
            Random rand = new Random();

            if (rand.NextDouble() > 0.2)
            {
                decimal change = (decimal)rand.NextDouble() * (rand.NextDouble() > 0.7 ? 10 : 2);

                Price += rand.Next(2) == 0 ? -change : change;
            }



        }


        public decimal Price
        {
            get { return price; }
            set
            {
                if (price == value) return;
                decimal oldPrice = price;
                price = value;
                OnPriceChanged(new PriceChangedEventArgs(oldPrice, price));
            }
        }

        public string Symbol { get => symbol; set => symbol = value; }

        public void stock_PriceChanged(object sender, PriceChangedEventArgs e)
        {
            //if (e.LastPrice != e.NewPrice)
            //    Print($"{Symbol} price has changed. Previous price was {e.LastPrice}, new price is {e.NewPrice}. The difference is {e.LastPrice - e.NewPrice}.");
            decimal difference = e.NewPrice - e.LastPrice;

            if (difference > 0)
            {
                Print($"{Symbol} increased from ${e.LastPrice} to ${e.NewPrice} (+${difference:F2})");

            }
            else
            {
                Print($"{Symbol} dropped from ${e.LastPrice} to ${e.NewPrice} (-${Math.Abs(difference):F2}).");
            }
        
        }

        public class PriceChangedEventArgs : EventArgs
        {
            public readonly decimal LastPrice;
            public readonly decimal NewPrice;

            public PriceChangedEventArgs(decimal lastPrice, decimal newPrice)
            {
                LastPrice = lastPrice; NewPrice = newPrice;
            }
        }

    }
}
