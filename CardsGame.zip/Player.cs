﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    public class Player
    {
        public int score;
        public string Name {  get; set; }
        public Deck PersonalDeck { get; private set; }
        public List<Card> Hand { get; private set; } = new List<Card>();

        //When they reach the highest Match card, they will have their own deck
        public Player() 
        {
            PersonalDeck = new Deck();
        }

        public void AddCard(Card card)
        {
            Hand.Add(card);
        }

        public void DiscardCard(Card card)
        { 
            Hand.Remove(card);
        }

        public int GetHighestSuitValue()
        {
            return Hand.GroupBy(c => c.Suit)
                .Select(group => group.Sum(c => c.Value))
                .Max();
        }


    }
}
