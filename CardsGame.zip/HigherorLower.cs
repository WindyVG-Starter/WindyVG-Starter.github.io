﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    internal class HigherorLower : Game
    {
        public override void play()
        {
            Deck deck = new Deck();
            Player player = new Player { Name = "Player", score = 0 };
            Player AI = new Player { Name = "AI", score = 0 };

            Card playerCard = deck.DrawCard();
            Card aiCard = deck.DrawCard();

            int rounds = 10;
            while (deck.HasCards() && rounds > 0)
            {
                Console.WriteLine($"Rounds left: {rounds}");
                Console.WriteLine($"{player.Name}'s card: ");
                playerCard.ShowCards();

                Console.Write("Is the next card gonna be high or low? (Higher/Lower): ");
                string guess;
                while (true)
                {
                    guess = Console.ReadLine()?.Trim().ToLower();
                    if (guess == "Higher" || guess == "Lower")
                        break;
                    Console.Clear();
                    Console.WriteLine("Next Card:");

                    Card nextCard = deck.DrawCard();

                    if ((nextCard.Value > playerCard.Value && guess == "Higher") ||
                        (nextCard.Value < playerCard.Value && guess == "Lower"))
                    {
                        player.score++;
                        Console.WriteLine($"Yay! Your score: {player.score}");

                    }
                    else
                    {
                        Console.WriteLine("Oops, try again");
                    }
                    playerCard = nextCard;



                    //This code belongs to the other player; AI
                    Card aiNextCard = deck.DrawCard();
                    Console.WriteLine($"{AI.Name} drew:  ");
                    aiNextCard.ShowCards();

                    string aiGuess = new Random().Next(2) == 0 ? "Higher" : "Lower";
                    if((aiNextCard.Value > aiCard.Value && aiGuess == "Higher") ||
                        (aiNextCard.Value < aiCard.Value && aiGuess == "Lower"))
                    {
                        AI.score++;
                    }
                    aiCard = aiNextCard;

                    Console.WriteLine($"{AI.Name}'s Score: {AI.score}");
                    rounds--;
                    Console.Write("Is the next card gonna be high or low? (Yes/No): ");

                }
                Console.WriteLine($"Game is OVER! Final Scores - {player.Name}: {player.score}, {AI.Name}: {AI.score}");





            }
          
            //Make the AI Draw a card when they have the highest card
            //Card limits is 10



        }
        
    }
}
