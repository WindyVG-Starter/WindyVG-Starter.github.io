﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    internal class HighestMatch : Game
    {
        public override void play()
        {
            Deck deck = new Deck();
            Player player = new Player { Name = "Player" };
            Player dealerAI = new Player { Name = "DealerAI" };

            int round = 10;

            for (int i = 0; i < 5; i++)
            {
                player.AddCard(deck.DrawCard());
                dealerAI.AddCard(deck.DrawCard());
            }

            while (round > 0 && deck.HasCards())
            {
                Console.WriteLine($"Rounds Left: {round}");
                Console.WriteLine("You currectly have: ");
                foreach (var card in player.Hand) card.ShowCards();

                Console.WriteLine("Do you want to get rid of one of your cards? (yes/no)");
                string choice = Console.ReadLine()?.Trim().ToLower();

                if (choice == "yes")
                {
                    Console.WriteLine("Enter the value of the card to get rid of it");
                    if (int.TryParse(Console.ReadLine(), out int value))
                    {
                        Card cardToDiscard = player.Hand.FirstOrDefault(c => c.Value == value);
                        if (cardToDiscard != null)
                        {
                            player.DiscardCard(cardToDiscard);
                            Console.WriteLine("The card went bye bye");
                        }
                        else
                        {
                            Console.WriteLine("Invalid answer, try again");
                        }

                    }

                }

                Card newCard = deck.DrawCard();
                player.AddCard(newCard);
                Console.WriteLine("You drew!: ");
                newCard.ShowCards();

                round--;


            }

            Console.WriteLine("Game Over, the results is...");
            int playerScore = player.GetHighestSuitValue();
            int dealerAIScore = dealerAI.GetHighestSuitValue();

            Console.WriteLine($"Your Score is: {playerScore}");
            Console.WriteLine($"Dealer's score is: {dealerAIScore}");

            if (playerScore > dealerAIScore)
                Console.WriteLine("Yay! You have Won!");
            else if (playerScore < dealerAIScore)
                Console.WriteLine("Oops! Better nect time!");
            else
                Console.WriteLine("OH MY GOSH, Look! It's a tie...");
        }
    }
}
