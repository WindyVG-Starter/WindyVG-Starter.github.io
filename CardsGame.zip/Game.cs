﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    public class Game
    {
        string rule;
        Deck deck;
        string player;
        public virtual void play() //It will call the ApplesOrOranges
        {

        }



    }
}
