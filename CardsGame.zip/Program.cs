﻿namespace CardGameS_VW
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            while (true)
            {
                ShowMenu();

                //This code is from the start, it's basically the menu
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        game = new ApplesorOranges();
                       
                        break;
                    case "2":
                        game = new HigherorLower();
                        break;
                    case "3":
                        game = new HighestMatch();
                        break;
                    case "4":
                        Console.WriteLine("OK! Bye!");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Press any key to try again...");
                        Console.ReadKey();
                        break;

                }
                game.play();




            }
            
        }



        //This is the description menu

        static void ShowMenu()

        {

            Console.WriteLine("\t \t \t \t \t \t  == Choose a Game! ==");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Short Description: Hello! Welcome! You have the choices to pick the 3 games below!");
            
            Console.WriteLine("1. Apples or Oranges?");
            Console.WriteLine("2. High or Low.");
            Console.WriteLine("3. High Matches??");
            Console.Write("Enter your choice:  ");



        }

        


    }







}
