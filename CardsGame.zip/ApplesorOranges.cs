﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    public class ApplesorOranges : Game
    {

        

        public override void play()
        {
            Deck deck = new Deck();
            Player player = new Player { Name = "Player", score = 0};
            int totalRound = 13;


            for (int round = 1; round <= totalRound; round++)
            {
                if (!deck.HasCards()) break;
            
                Console.WriteLine($"Round {round} of {totalRound}");
                (Card cardA, Card cardB) = deck.DrawCards();

                string guess;
                while (true)
                {

                    Console.Write("What is your thought? Will the next card be the same or not? (yes/no):  ");
                    Console.Write("Type yes for same, type no for difference.");
                    guess = Console.ReadLine()?.Trim().ToLower();

                    if (guess == "yes" || guess == "no")
                    {
                        break;
                    }
                    Console.Clear();
                    Console.WriteLine("Only yes or no, try again");
                }



                if ((cardA.Suit == cardB.Suit && guess == "yes") || (cardA.Suit != cardB.Suit && guess == "no"))
                {
                        player.score++;
                        Console.WriteLine($"Yay! Your score is {player.score}");
                }
                else
                {
                        Console.WriteLine("Sorry, you're incorrect, keep doing your best!");

                }

                
                


            }

            Console.WriteLine($"Game over! Yoour final score is {player.score}.");

        }
    }
}
