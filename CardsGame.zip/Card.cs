﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    public class Card
    {
        public string Suit { get; private set; }
        public int Value { get; private set; }
    
        public Card(string suit, int value)
        {
            Suit = suit;
            Value = value;
        }

        public void ShowCards()
        {
            Console.WriteLine($"Card: {Suit}, Value: {Value}");
        }




        //public override string ToString()
        //{
        //    return $"{Rank} of {Suit}";
        //}

    }
}
