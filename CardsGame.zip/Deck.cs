﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameS_VW
{
    public class Deck
    {
        private List<Card> cards;
        private Random rand = new Random();

        public Deck()
        {
            cards = new List<Card>();
            for (int i = 1; i <= 10; i++)
            {
                cards.Add(new Card("Apples", i));
                cards.Add(new Card("Oranges", i));

            }
            Shuffle();
        }

        public void Shuffle()
        {
            for (int i = 0; i < cards.Count; i++)
            {
                int j = rand.Next(cards.Count);
                (cards[i], cards[j]) = (cards[j], cards[i]);
            }

        }

        public bool HasCards() => cards.Count > 1;

        public (Card, Card) DrawCards()
        {
            if (cards.Count < 2) throw new InvalidOperationException("There's not enough cards.");
            Card cardA = cards[0];
            Card cardB = cards[1];
            cards.RemoveRange(0, 2);
            return (cardA, cardB);
        }

        public Card DrawCard()
        {
            if (cards.Count == 0) throw new InvalidOperationException("No more cards.");
            Card drawnCard = cards[0];
            cards.RemoveAt(0);
            return drawnCard;
        }



    }

}
